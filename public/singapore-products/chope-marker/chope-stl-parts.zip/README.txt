CHOPE marker - three colour parts
Assembled size: 60 x 38 x 12 mm.

Recommended: open chope-multipart.3mf in Bambu Studio as geometry.
Expand CHOPE marker in the Objects list. Assign a filament to Packet body,
CHOPE lettering, and Tissue. Keep these as parts of one assembled object.

STL alternative: select all three STL files and import them together.
Choose to load them as one object with multiple parts. Keep their relative
positions. The lettering and tissue start at Z=10 mm on top of the body.
Do not arrange or drop the individual parts separately onto the plate.

Select your Bambu Lab A1 and PLA settings, then slice and preview.
This is an unsliced model. Assign your own AMS Lite filament slots.
Physical printing and colour results have not been tested.
