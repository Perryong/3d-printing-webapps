KOPITIAM KEYCAP CLICKER
Print the saucer base and either cap at 100% scale in millimetres.
The set STL contains all three pieces spaced apart on the bed.
The ZIP also contains an individual STL for each piece.

Use a full-height plate-mount MX-style clicky switch with a cross stem,
such as CHERRY MX Blue, and a metal split ring. Source these separately.
Print the base flat and the caps socket down. Inspect the cap cavity and cup
handle for supports; keep support material out of the small cross socket.
Press the switch into the square opening until its clips engage. Gently seat
one cap on the stem. Thread the ring through the side eyelet. To change
caps, hold the switch housing and lift the cap straight up.
No wiring is required. Fit, travel and keyring strength need a physical test.
